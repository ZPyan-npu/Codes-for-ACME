clear
clc

N = 10;
Beta = 1;
F = 1.25;
Kesi = 0.1;
phidegree = 5;

M = 2 * (phidegree) * N + 1;
Qxb = 0 * ones(1, M)';
Omega = 2;
[X, ~, flag] = Newton_Raphson(M, N, Omega, Kesi, Beta, F, Qxb, phidegree);