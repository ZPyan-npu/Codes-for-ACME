clear;
clc;
close all;

fontName = 'Arial';
fontSize = 16;


RHB_computing_time_high_cubic = [0.013; 0.026; 0.049; 0.076; 0.121; 0.192; 0.362; 0.610; 0.998; 1.430];
AFT_computing_time_high_cubic = [0.014; 0.034; 0.067; 0.124; 0.216; 0.403; 0.864; 1.554; 2.595; 3.742];
Computing_time_high_cubic = [RHB_computing_time_high_cubic, AFT_computing_time_high_cubic];
RHB_AFT_computing_time_ratio_cubic = AFT_computing_time_high_cubic ./ RHB_computing_time_high_cubic;

RHB_computing_time_high_quantic = [0.014; 0.029; 0.056; 0.090; 0.215; 0.526; 0.985; 1.559; 2.318; 2.795];
AFT_computing_time_high_quantic = [0.015; 0.041; 0.093; 0.185; 0.625; 1.638; 3.139; 5.020; 7.452; 9.099];
Computing_time_high_quantic = [RHB_computing_time_high_quantic, AFT_computing_time_high_quantic];
RHB_AFT_computing_time_ratio_quantic = AFT_computing_time_high_quantic ./ RHB_computing_time_high_quantic;

subplot(1, 2, 1);
yyaxis left
Bar = bar(Computing_time_high_cubic);
grid on;
set(gca, 'XGrid', 'off');
Bar(1).FaceColor = [0.11176 0.29216 0.44510];
Bar(2).FaceColor = [0.25098 0.87843 0.81569];
set(gca, 'XTickLabel', {'10', '30', '50', '70', '90', '110', '130', '150', '170', '190'});
set(gca,'YLim',[0, 4]);
xlabel('Wavenumber');
ylabel('Computing time (s)');
set(gca, 'Ycolor', 'k');
yyaxis right;
plot(1 : 10, RHB_AFT_computing_time_ratio_cubic, 'LineWidth', 2, 'Color', [0.69020 0.18824 0.37647]);
set(gca, 'Ycolor', [0.69020 0.18824 0.37647]);
ylabel('Ratio');

set(gca, 'FontSize', fontSize);
set(gca, 'FontName', fontName);
PlotLegend = legend(' RHB', ' AFT', ' Ratio');
set(PlotLegend, 'Box', 'off');
set(PlotLegend, 'Location', 'best');
set(PlotLegend, 'FontSize', fontSize);
set(PlotLegend, 'FontName', fontName);

subplot(1, 2, 2);
yyaxis left
Bar = bar(Computing_time_high_quantic);
grid on;
set(gca, 'XGrid', 'off');
Bar(1).FaceColor = [0.11176 0.29216 0.44510];
Bar(2).FaceColor = [0.25098 0.87843 0.81569];
set(gca, 'XTickLabel', {'10', '30', '50', '70', '90', '110', '130', '150', '170', '190'});
set(gca,'YLim',[0, 10]);
xlabel('Wavenumber');
ylabel('Computing time (s)');
set(gca, 'Ycolor', 'k');
yyaxis right;
plot(1 : 10, RHB_AFT_computing_time_ratio_quantic, 'LineWidth', 2, 'Color', [0.69020 0.18824 0.37647]);
set(gca, 'Ycolor', [0.69020 0.18824 0.37647]);
ylabel('Ratio');

set(gca, 'FontSize', fontSize);
set(gca, 'FontName', fontName);
PlotLegend = legend(' RHB', ' AFT', ' Ratio');
set(PlotLegend, 'Box', 'off');
set(PlotLegend, 'Location', 'best');
set(PlotLegend, 'FontSize', fontSize);
set(PlotLegend, 'FontName', fontName);