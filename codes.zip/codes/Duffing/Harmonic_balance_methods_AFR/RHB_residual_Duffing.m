%===================================================================================================
% DESCRIPTION: 
% Matlab function setting up the frequency-domain residual vector 'R' and its derivatives for given 
% frequency 'Om' and vector of harmonics of the generalized coordiantes 'Q'. The corresponding model
% is a single DOF oscillator with cubic Duffing oscillator governed by the time-domain equation of 
% motion
% 
%       mu * \ddot q + zeta * \dot q + kappa * q + gamma * q^3 = P * sin(Om*t).
% 
%===================================================================================================
function R = RHB_residual_Duffing(X, zeta, kappa, gamma, P, N, M, A_tilde, phi)
    Om = X(end);                           % excitation frequency
    T = 2 * pi / Om;                       % period
    t_i = (0 : M - 1) / M * T; t_i = t_i'; % collocations
    H = sin(Om .* t_i);
    
    [E, pinvE] = Changeable_values(Om, M, N);
    E_tilde = blkdiag(E, E);
    pinvE_tilde = blkdiag(pinvE, pinvE);
    X_tilde = E_tilde * X(1 : end - 1);
    
%     Linear_coef = [0 * eye(2 * N + 1), 1 * eye(2 * N + 1); -kappa * eye(2 * N + 1), -zeta * eye(2 * N + 1)];
%     Nonlinear_coef = [0 * eye(2 * N + 1), 0 * eye(2 * N + 1); -gamma * eye(2 * N + 1), 0 * eye(2 * N + 1)];
%     External_coef = [0 * ones(M, 1); P * H];
%     
%     R = Om * A_tilde * X(1 : end - 1) - Linear_coef * X(1 : end - 1) - Nonlinear_coef * pinvE_tilde * X_tilde .^ phi - pinvE_tilde * External_coef;
    Linear_coef1 = [0 * eye(M), 1 * eye(M); -kappa * eye(M), -zeta * eye(M)];
    Nonlinear_coef1 = [0 * eye(M), 0 * eye(M); -gamma * eye(M), 0 * eye(M)];
    External_coef = [0 * ones(M, 1); P * H];
    
    R = Om * A_tilde * X(1 : end - 1) - pinvE_tilde * Linear_coef1 * X_tilde - pinvE_tilde * Nonlinear_coef1 * X_tilde .^ phi - pinvE_tilde * External_coef;
end