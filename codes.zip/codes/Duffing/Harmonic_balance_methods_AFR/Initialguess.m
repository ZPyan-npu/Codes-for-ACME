function [X_hat, Xdot_hat] = Initialguess(N, Omega, zeta, kappa, P, A_tilde, X_hat)
    Error_lim = 1e-8;
    Error = 1;
    
    while Error > Error_lim
        X_hatFormer = X_hat;
        [J, R] = Initialguess_Jacobian(X_hat, N, Omega, A_tilde, zeta, kappa, P);
        X_hat = X_hatFormer - pinv(J) * R;
        Error = sum(abs(R));
        Xdot_hat = Omega * A_tilde * X_hat;
    end
end

function [J, R] = Initialguess_Jacobian(X_hat, N, Omega, A_tilde, zeta, kappa, P)
    Linear_coefficient  =  [0  *  eye(2  *  N  +  1),  1  *  eye(2  *  N  +  1);   - kappa  *  eye(2  *  N  +  1),   - zeta  *  eye(2  *  N  +  1)]; 
    
    switch N
        case 1
            H = [0; 0; 1];
            Rp1 = [3 * X_hat(1) ^ 2 + 3 / 2 * X_hat(2) ^ 2 + 3 / 2 * X_hat(3) ^ 2; 6 * X_hat(1) * X_hat(2); 6 * X_hat(1) * X_hat(3);];
            Rp2 = [3 * X_hat(1) * X_hat(2); 3 * X_hat(1) ^ 2 + 9 / 4 * X_hat(2) ^ 2 + 3 / 4 * X_hat(3) ^ 2; 3 / 2 * X_hat(2) * X_hat(3);];
            Rp3 = [3 * X_hat(1) * X_hat(3); 3 / 2 * X_hat(2) * X_hat(3); 3 * X_hat(1) ^ 2 + 3 / 4 * X_hat(2) ^ 2 + 9 / 4 * X_hat(3) ^ 2;];
            Rp = [Rp1, Rp2, Rp3];
            Rx1 = (X_hat(1) ^ 2 + 3 / 2 * X_hat(2) ^ 2 + 3 / 2 * X_hat(3) ^ 2) * X_hat(1);
            Rx2 = (3 * X_hat(1) ^ 2 + 3 / 4 * X_hat(2) ^ 2 + 3 / 4 * X_hat(3) ^ 2) * X_hat(2);
            Rx3 = (3 * X_hat(1) ^ 2 + 3 / 4 * X_hat(2) ^ 2 + 3 / 4 * X_hat(3) ^ 2) * X_hat(3);
            Rx = [Rx1; Rx2; Rx3];
        case 2
            H = [0; 0; 1; 0; 0]; 
            Rp1 = [3 / 2 * (2 * X_hat(1) ^ 2 + (X_hat(2) ^ 2 + X_hat(3) ^ 2 + X_hat(4) ^ 2 + X_hat(5) ^ 2)); 
                3 * (2 * X_hat(1) * X_hat(2) + X_hat(2) * X_hat(4) + X_hat(3) * X_hat(5)); 
                3 * (2 * X_hat(1) * X_hat(3) - X_hat(3) * X_hat(4) + X_hat(2) * X_hat(5)); 
                3 / 2 * ((X_hat(2) ^ 2 - X_hat(3) ^ 2) + 4 * X_hat(1) * X_hat(4)); 
                3 * (X_hat(2) * X_hat(3) + 2 * X_hat(1) * X_hat(5))]; 
            Rp2 = [3 / 2 * (2 * X_hat(1) * X_hat(2) + X_hat(2) * X_hat(4) + X_hat(3) * X_hat(5)); 
                3 / 4 * (4 * X_hat(1) ^ 2 + 3 * X_hat(2) ^ 2 + X_hat(3) ^ 2 + 4 * X_hat(1) * X_hat(4) + 2 * (X_hat(4) ^ 2 + X_hat(5) ^ 2)); 
                3 / 2 * (X_hat(2) * X_hat(3) + 2 * X_hat(1) * X_hat(5)); 
                3 * (X_hat(1) * (2) + X_hat(2) * X_hat(4)); 
                3 * (X_hat(1) * X_hat(3) + X_hat(2) * X_hat(5))]; 
            Rp3 = [3 / 2 * (2 * X_hat(1) * X_hat(3) - X_hat(3) * X_hat(4) + X_hat(2) * X_hat(5)); 
                3 / 2 * (X_hat(2) * X_hat(3) + 2 * X_hat(1) * X_hat(5)); 
                3 / 4 * (4 * X_hat(1) ^ 2 + X_hat(2) ^ 2 + 3 * X_hat(3) ^ 2 - 4 * X_hat(1) * X_hat(4) + 2 * X_hat(4) ^ 2 + 2 * X_hat(5) ^ 2); 
                3 * ( - X_hat(1) * X_hat(3) + X_hat(3) * X_hat(4)); 
                3 * (X_hat(1) * X_hat(2) + X_hat(3) * X_hat(5))]; 
            Rp4 = [3 / 4 * (X_hat(2) ^ 2 - X_hat(3) ^ 2 + 4 * X_hat(1) * X_hat(4)); 3 * (X_hat(1) * X_hat(2) + X_hat(2) * X_hat(3)); 3 * ( - X_hat(1) * X_hat(3) + X_hat(3) * X_hat(4)); 3 / 4 * (4 * X_hat(1) ^ 2 + 2 * X_hat(2) ^ 2 + 2 * X_hat(3) ^ 2 + 3 * X_hat(4) ^ 2 + X_hat(5) ^ 2); 3 / 2 * X_hat(4) * X_hat(5)]; 
            Rp5 = [3 / 2 * (X_hat(2) * X_hat(3) + 2 * X_hat(1) * X_hat(5)); 3 * (X_hat(1) * X_hat(3) + X_hat(2) * X_hat(5)); 3 * (X_hat(1) * X_hat(2) + X_hat(3) * X_hat(5)); 3 / 2 * X_hat(4) * X_hat(5); 3 / 4 * (4 * X_hat(1) ^ 2 + 2 * X_hat(2) ^ 2 + 2 * X_hat(3) ^ 2 + X_hat(4) ^ 2 + 3 * X_hat(5) ^ 2)]; 
            Rp = [Rp1, Rp2, Rp3, Rp4, Rp5]; 
            Rx1 = 1 / 4 * (4 * X_hat(1) ^ 3 + 3 * X_hat(2) ^ 2 * X_hat(4) - 3 * X_hat(3) ^ 2 * X_hat(4) + 6 * X_hat(2) * X_hat(3) * X_hat(5) + 6 * X_hat(1) * (X_hat(2) ^ 2 + X_hat(3) ^ 2 + X_hat(4) ^ 2 + X_hat(5) ^ 2)); 
            Rx2 = 3 / 4 * (4 * X_hat(1) ^ 2 * X_hat(2) + 4 * X_hat(1) * (X_hat(2) * X_hat(4) + X_hat(3) * X_hat(5)) + X_hat(2) * (X_hat(2) ^ 2 + X_hat(3) ^ 2 + 2 * (X_hat(4) ^ 2 + X_hat(5) ^ 2))); 
            Rx3 = 3 / 4 * (4 * X_hat(1) ^ 2 * X_hat(3) + 4 * X_hat(1) * ( - X_hat(3) * X_hat(4) + X_hat(2) * X_hat(5)) + X_hat(3) * (X_hat(2) ^ 2 + X_hat(3) ^ 2 + 2 * (X_hat(4) ^ 2 + X_hat(5) ^ 2))); 
            Rx4 = 3 / 4 * (2 * X_hat(1) * (X_hat(2) ^ 2 - X_hat(3) ^ 2) + 4 * X_hat(1) ^ 2 * X_hat(4) + X_hat(4) * (2 * X_hat(2) ^ 2 + 2 * X_hat(3) ^ 2 + X_hat(4) ^ 2 + X_hat(5) ^ 2)); 
            Rx5 = 3 / 4 * (4 * X_hat(1) * X_hat(2) * X_hat(3) + 4 * X_hat(1) ^ 2 * X_hat(5) + X_hat(5) * (2 * X_hat(2) ^ 2 + 2 * X_hat(3) ^ 2 + X_hat(4) ^ 2 + X_hat(5) ^ 2)); 
            Rx = [Rx1;  Rx2;  Rx3;  Rx4;  Rx5]; 
        case 3
            H = [0; 0; 1; 0; 0; 0; 0]; 
            X1 = X_hat(1);  X2 = X_hat(2);  X3 = X_hat(3);  X4 = X_hat(4);  X5 = X_hat(5);  X6 = X_hat(6);  X7 = X_hat(7); 
            Rp1 = [3 * X1 ^ 2  +  (3 * X2 ^ 2) / 2  +  (3 * X3 ^ 2) / 2  +  (3 * X4 ^ 2) / 2  +  (3 * X5 ^ 2) / 2  +  (3 * X6 ^ 2) / 2  +  (3 * X7 ^ 2) / 2; 
               3 * X1 * X2  +  (3 * X2 * X4) / 2  +  (3 * X3 * X5) / 2  +  (3 * X4 * X6) / 2  +  (3 * X5 * X7) / 2; 
               3 * X1 * X3  -  (3 * X3 * X4) / 2  +  (3 * X2 * X5) / 2  -  (3 * X5 * X6) / 2  +  (3 * X4 * X7) / 2; 
               (3 * X2 ^ 2) / 4  -  (3 * X3 ^ 2) / 4  +  3 * X1 * X4  +  (3 * X2 * X6) / 2  +  (3 * X3 * X7) / 2; 
               (3 * X2 * X3) / 2  +  3 * X1 * X5  -  (3 * X3 * X6) / 2  +  (3 * X2 * X7) / 2; 
               (3 * X2 * X4) / 2  -  (3 * X3 * X5) / 2  +  3 * X1 * X6; 
               (3 * X3 * X4) / 2  +  (3 * X2 * X5) / 2  +  3 * X1 * X7]; 
            Rp2 = [3 / 4 * (8 * X1 * X2  +  4 * (X2 * X4  +  X3 * X5  +  X4 * X6  +  X5 * X7)); 
               3 / 4 * (4 * X1 ^ 2  +  3 * X2 ^ 2  +  X3 ^ 2  +  4 * X1 * X4  +  2 * X2 * X6  +  2 * X3 * X7  +  2 * (X4 ^ 2  +  X5 ^ 2  +  X6 ^ 2  +  X7 ^ 2)); 
               3 / 4 * (4 * X1 * X5  -  2 * X3 * X6  +  X2 * (2 * X3  +  2 * X7)); 
               3 / 4 * (4 * X2 * X4  +  2 * X4 * X6  +  4 * X1 * (X2  +  X6)  +  2 * X5 * X7); 
               3 / 4 * (4 * X2 * X5  -  2 * X5 * X6  +  2 * X4 * X7  +  4 * X1 * (X3  +  X7)); 
               3 / 4 * (X2 ^ 2  -  X3 ^ 2  +  4 * X1 * X4  +  X4 ^ 2  -  X5 ^ 2  +  4 * X2 * X6); 
               3 / 4 * (4 * X1 * X5  +  2 * X4 * X5  +  X2 * (2 * X3  +  4 * X7))]; 
            Rp3 = [3 / 4 * (8 * X1 * X3  -  4 * (X3 * X4  -  X2 * X5  +  X5 * X6  -  X4 * X7)); 
               3 / 4 * (4 * X1 * X5  -  2 * X3 * X6  +  2 * X2 * (X3  +  X7)); 
               3 / 4 * (4 * X1 ^ 2  +  X2 ^ 2  +  3 * X3 ^ 2  -  4 * X1 * X4  +  2 * X4 ^ 2  +  2 * X5 ^ 2  -  2 * X2 * X6  +  2 * X6 ^ 2  -  2 * X3 * X7  +  2 * X7 ^ 2); 
               3 / 4 * (4 * X3 * X4  +  2 * X5 * X6  -  4 * X1 * (X3  -  X7)  -  2 * X4 * X7); 
               3 / 4 * (4 * X3 * X5  +  2 * X4 * X6  -  4 * X1 * ( - X2  +  X6)  +  2 * X5 * X7); 
               3 / 4 * ( - 2 * X2 * X3  -  4 * X1 * X5  +  2 * X4 * X5  +  4 * X3 * X6); 
               3 / 4 * (X2 ^ 2  -  X3 ^ 2  +  4 * X1 * X4  -  X4 ^ 2  +  X5 ^ 2  +  4 * X3 * X7)]; 
            Rp4 = [3 / 4 * (8 * X1 * X4  +  2 * (X2 ^ 2  +  2 * X2 * X6  -  X3 * (X3  -  2 * X7))); 
               3 / 4 * (4 * X2 * X4  +  2 * X1 * (2 * X2  +  2 * X6)  +  2 * (X4 * X6  +  X5 * X7)); 
               3 / 4 * (4 * X3 * X4  +  2 * X5 * X6  -  2 * X4 * X7  +  2 * X1 * ( - 2 * X3  +  2 * X7)); 
               3 / 4 * (4 * X1 ^ 2  +  2 * X2 ^ 2  +  2 * X3 ^ 2  +  3 * X4 ^ 2  +  X5 ^ 2  +  2 * X2 * X6  +  2 * X6 ^ 2  -  2 * X3 * X7  +  2 * X7 ^ 2); 
               3 / 4 * (2 * X4 * X5  +  2 * X3 * X6  +  2 * X2 * X7); 
               3 / 4 * (4 * X1 * X2  +  2 * X2 * X4  +  2 * X3 * X5  +  4 * X4 * X6); 
               3 / 4 * (4 * X1 * X3  -  2 * X3 * X4  +  2 * X2 * X5  +  4 * X4 * X7)]; 
            Rp5 = [3 / 4 * (8 * X1 * X5  -  4 * X3 * X6  +  4 * X2 * (X3  +  X7)); 
               3 / 4 * (4 * X2 * X5  -  2 * X5 * X6  +  2 * X4 * X7  +  4 * X1 * (X3  +  X7)); 
               3 / 4 * (4 * X1 * X2  +  4 * X3 * X5  -  4 * X1 * X6  +  2 * X4 * X6  +  2 * X5 * X7); 
               3 / 4 * (2 * X4 * X5  +  2 * X3 * X6  +  2 * X2 * X7); 
               3 / 4 * (4 * X1 ^ 2  +  2 * X2 ^ 2  +  2 * X3 ^ 2  +  X4 ^ 2  +  3 * X5 ^ 2  -  2 * X2 * X6  +  2 * X6 ^ 2  +  2 * X3 * X7  +  2 * X7 ^ 2); 
               3 / 4 * ( - 4 * X1 * X3  +  2 * X3 * X4  -  2 * X2 * X5  +  4 * X5 * X6); 
               3 / 4 * (4 * X1 * X2  +  2 * X2 * X4  +  2 * X3 * X5  +  4 * X5 * X7)]; 
            Rp6 = [1 / 4 * (12 * X2 * X4  +  3 * ( - 4 * X3 * X5  +  8 * X1 * X6)); 
               1 / 4 * (3 * X2 ^ 2  -  3 * (X3 ^ 2  -  4 * X1 * X4  -  X4 ^ 2  +  X5 ^ 2)  +  12 * X2 * X6); 
               1 / 4 * ( - 6 * X2 * X3  +  3 * ( - 4 * X1 * X5  +  2 * X4 * X5  +  4 * X3 * X6)); 
               1 / 4 * ( - 3 * X2 * ( - 4 * X1  -  2 * X4)  +  3 * (2 * X3 * X5  +  4 * X4 * X6)); 
               1 / 4 * ( - 6 * X2 * X5  +  3 * ( - 4 * X1 * X3  +  2 * X3 * X4  +  4 * X5 * X6)); 
               1 / 4 * (6 * X2 ^ 2  +  3 * (4 * X1 ^ 2  +  2 * X3 ^ 2  +  2 * X4 ^ 2  +  2 * X5 ^ 2  +  3 * X6 ^ 2  +  X7 ^ 2)); 
               (3 * X6 * X7) / 2]; 
            Rp7 = [1 / 4 * (12 * X3 * X4  +  12 * X2 * X5  +  24 * X1 * X7); 
               1 / 4 * (6 * (2 * X1  +  X4) * X5  +  6 * X2 * (X3  +  2 * X7)); 
               1 / 4 * (3 * X2 ^ 2  -  3 * X3 ^ 2  +  3 * (4 * X1 * X4  -  X4 ^ 2  +  X5 ^ 2)  +  12 * X3 * X7); 
               1 / 4 * (3 * X3 * (4 * X1  -  2 * X4)  +  6 * X2 * X5  +  12 * X4 * X7); 
               1 / 4 * (6 * X2 * (2 * X1  +  X4)  +  6 * X3 * X5  +  12 * X5 * X7); 
               (3 * X6 * X7) / 2; 
               1 / 4 * (6 * X2 ^ 2  +  6 * X3 ^ 2  +  6 * X7 ^ 2  +  3 * (4 * X1 ^ 2  +  2 * X4 ^ 2  +  2 * X5 ^ 2  +  X6 ^ 2  +  X7 ^ 2))]; 
            Rp = [Rp1, Rp2, Rp3, Rp4, Rp5, Rp6, Rp7]; 
            Rx1 = X1 ^ 3  +  (3 * X1 * X2 ^ 2) / 2  +  (3 * X1 * X3 ^ 2) / 2  +  (3 * X2 ^ 2 * X4) / 4  -  (3 * X3 ^ 2 * X4) / 4  +  (3 * X1 * X4 ^ 2) / 2  +  (3 * X2 * X3 * X5) / 2  +  (3 * X1 * X5 ^ 2) / 2  +  (3 * X2 * X4 * X6) / 2  -  (3 * X3 * X5 * X6) / 2  +  (3 * X1 * X6 ^ 2) / 2  +  (3 * X3 * X4 * X7) / 2  +  (3 * X2 * X5 * X7) / 2  +  (3 * X1 * X7 ^ 2) / 2; 
            Rx2 = 3 / 4 * (4 * X1 ^ 2 * X2  +  X2 ^ 3  +  X2 ^ 2 * X6  -  X3 ^ 2 * X6  +  X4 ^ 2 * X6  -  X5 ^ 2 * X6  +  2 * X4 * X5 * X7  +  4 * X1 * (X2 * X4  +  X3 * X5  +  X4 * X6  +  X5 * X7)  +  X2 * (X3 ^ 2  +  2 * X3 * X7  +  2 * (X4 ^ 2  +  X5 ^ 2  +  X6 ^ 2  +  X7 ^ 2))); 
            Rx3 = 3 / 4 * (4 * X1 ^ 2 * X3  +  X3 ^ 3  +  2 * X3 * X4 ^ 2  +  2 * X3 * X5 ^ 2  -  2 * X2 * X3 * X6  +  2 * X4 * X5 * X6  +  2 * X3 * X6 ^ 2  -  X3 ^ 2 * X7  -  X4 ^ 2 * X7  +  X5 ^ 2 * X7  +  2 * X3 * X7 ^ 2  +  X2 ^ 2 * (X3  +  X7)  -  4 * X1 * (X3 * X4  -  X2 * X5  +  X5 * X6  -  X4 * X7)); 
            Rx4 = 3 / 4 * (4 * X1 ^ 2 * X4  +  2 * X2 ^ 2 * X4  +  2 * X3 ^ 2 * X4  +  X4 ^ 3  +  X4 * X5 ^ 2  +  2 * X3 * X5 * X6  +  2 * X4 * X6 ^ 2  +  2 * X1 * (X2 ^ 2  +  2 * X2 * X6  -  X3 * (X3  -  2 * X7))  -  2 * X3 * X4 * X7  +  2 * X4 * X7 ^ 2  +  2 * X2 * (X4 * X6  +  X5 * X7)); 
            Rx5 = 3 / 4 * (4 * X1 ^ 2 * X5  +  2 * X2 ^ 2 * X5  +  2 * X3 ^ 2 * X5  +  X4 ^ 2 * X5  +  X5 ^ 3  -  4 * X1 * X3 * X6  +  2 * X3 * X4 * X6  -  2 * X2 * X5 * X6  +  2 * X5 * X6 ^ 2  +  2 * X2 * X4 * X7  +  2 * X3 * X5 * X7  +  2 * X5 * X7 ^ 2  +  4 * X1 * X2 * (X3  +  X7)); 
            Rx6 = 1 / 4 * (X2 ^ 3  -  3 * X2 * (X3 ^ 2  -  4 * X1 * X4  -  X4 ^ 2  +  X5 ^ 2)  +  6 * X2 ^ 2 * X6  +  3 * ( - 4 * X1 * X3 * X5  +  2 * X3 * X4 * X5  +  4 * X1 ^ 2 * X6  +  2 * X3 ^ 2 * X6  +  X6 * (2 * X4 ^ 2  +  2 * X5 ^ 2  +  X6 ^ 2  +  X7 ^ 2))); 
            Rx7 = 1 / 4 * ( - X3 ^ 3  +  6 * X2 * (2 * X1  +  X4) * X5  +  3 * X3 * (4 * X1 * X4  -  X4 ^ 2  +  X5 ^ 2)  +  6 * X3 ^ 2 * X7  +  3 * X2 ^ 2 * (X3  +  2 * X7)  +  3 * X7 * (4 * X1 ^ 2  +  2 * X4 ^ 2  +  2 * X5 ^ 2  +  X6 ^ 2  +  X7 ^ 2)); 
            Rx = [Rx1; Rx2; Rx3; Rx4; Rx5; Rx6; Rx7]; 
    end
    
    External_coefficient = [0 * ones(2 * N + 1, 1); P * H];
    
    J = Omega * A_tilde - Linear_coefficient + [zeros(2 * N + 1), zeros(2 * N + 1); Rp, zeros(2 * N + 1)];
    
    R = Omega * A_tilde * X_hat - Linear_coefficient * X_hat + [0 * ones(2 * N + 1, 1); Rx] - External_coefficient;
end