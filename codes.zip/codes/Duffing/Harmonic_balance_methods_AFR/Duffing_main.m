%=======================================================================================================
% DESCRIPTION: 
% Investigation of the dynamics the Duffing oscillator, under harmonic external forcing and light linear 
% viscous damping. The dynamics are governed by the second-order ordinary diferential equation,
%   \ddot q + zeta \dot q + kappa q + \gamma q^3 = P sin( Om * t ).
%=======================================================================================================
% clearvars;
% close all;
% clc;

%% Parameters of the Duffing oscillator and analysis
[kappa, P, zeta, phi, gamma] = System_coefficients(); % Duffing oscillator parameters
N = 3;                    % harmonic order
Om_s = 0.01;              % start frequency
Om_e = 3.00;              % end frequency
[A] = Constant_values(N); % matrix A
A_tilde = blkdiag(A, A);

%% Compute frequency response using the HB method
% Initial guess
X_hat_Initial = 0 * ones(2 * (2 * N + 1), 1);%Initial Fourier coefficients
[X_hat_first, ~] = Initialguess(N, Om_s, zeta, kappa, P, A_tilde, X_hat_Initial);%the first solution point
% Solve and continuation
ds = 0.01;                       % Path continuation step size
Sopt = struct('jac', 'none');    % No analytical Jacobian provided here
X = solve_and_continue(X_hat_first, @(X) HB_residual_Duffing(X, zeta, kappa, gamma, P, N, A_tilde), Om_s, Om_e, ds, Sopt);

% Determine excitation frequency and amplitude (magnitude of fundamental harmonic)
Om_HB = X(end, :);
switch N
    case 1
        Amplitude_HB = abs(X(1, :)) + sqrt(X(2, :) .^ 2 + X(3, :) .^ 2);
    case 2
        Amplitude_HB = abs(X(1, :)) + sqrt(X(2, :) .^ 2 + X(3, :) .^ 2) + sqrt(X(4, :) .^ 2 + X(5, :) .^ 2);
    case 3
        Amplitude_HB = abs(X(1, :)) + sqrt(X(2, :) .^ 2 + X(3, :) .^ 2) + sqrt(X(4, :) .^ 2 + X(5, :) .^ 2) + sqrt(X(6, :) .^ 2 + X(7, :) .^ 2);
end

%% Compute frequency response using the RHB method
% Number of collocations
M = 13;

% Initial guess

% Solve and continuation
X = solve_and_continue(X_hat_first, @(X) RHB_residual_Duffing(X, zeta, kappa, gamma, P, N, M, A_tilde, phi), Om_s, Om_e, ds, Sopt);

% Determine excitation frequency and amplitude (magnitude of fundamental harmonic)
Om_RHB = X(end, :);
Amplitude_RHB = zeros(1, length(X(end, :)));
for i = 1 : length(X(end, :))
    X_RHB_hat = X(1 : end - 1, i);
    Amplitude_RHB(i) = abs(X_RHB_hat(1));
    for j = 1 : N
        Amplitude_RHB(i) = Amplitude_RHB(i) + sqrt(X_RHB_hat(2 * j) ^ 2 + X_RHB_hat(2 * j + 1) ^ 2);
    end
end

%% Compute frequency response using the HDHB method (forward)
% % Number of collocations
% M = 2 * N + 1;
% 
% % Initial guess
% [E, ~] = Changeable_values(Om_s, M, N);
% E_tilde = blkdiag(E, E);
% X_tilde_first = E_tilde * X_hat_first;
% 
% % Solve and continuation
% X = solve_and_continue(X_tilde_first, @(X) HDHB_residual_Duffing(X, zeta, kappa, gamma, P, N, M, A_tilde, phi), Om_s, Om_e, ds, Sopt);
% 
% % Determine excitation frequency and amplitude (magnitude of fundamental harmonic)
% Om_HDHB_for = X(end, :);
% Amplitude_HDHB_for = zeros(1, length(X(end, :)));
% for i = 1 : length(X(end, :))
%     [~, pinvE] = Changeable_values(Om_HDHB_for(i), M, N);
%     X_HDHB_hat = blkdiag(pinvE, pinvE) * X(1 : end - 1, i);
%     Amplitude_HDHB_for(i) = abs(X_HDHB_hat(1));
%     for j = 1 : N
%         Amplitude_HDHB_for(i) = Amplitude_HDHB_for(i) + sqrt(X_HDHB_hat(2 * j) ^ 2 + X_HDHB_hat(2 * j + 1) ^ 2);
%     end
% end

%% Compute frequency response using the HDHB method (backward)
% Om_s_HDHBback = Om_e;
% Om_e_HDHBback = Om_s;
% Number of collocations
% 
% Initial guess
% X_hat_Initial = 0 * ones(2 * (2 * N + 1), 1);%Initial Fourier coefficients
% [X_hat_first, ~] = Initialguess(N, Om_s_HDHBback, zeta, kappa, P, A_tilde, X_hat_Initial);%the first solution point
% [E, ~] = Changeable_values(Om_s, M, N);
% E_tilde = blkdiag(E, E);
% X_tilde_first = E_tilde * X_hat_first;
% 
% Solve and continuation
% X = solve_and_continue(X_tilde_first, @(X) HDHB_residual_Duffing(X, zeta, kappa, gamma, P, N, M, A_tilde, phi), Om_s_HDHBback, Om_e_HDHBback, ds, Sopt);
% 
% Determine excitation frequency and amplitude (magnitude of fundamental harmonic)
% Om_HDHB_back = X(end, :);
% Amplitude_HDHB_back = zeros(1, length(X(end, :)));
% for i = 1 : length(X(end, :))
%     [~, pinvE] = Changeable_values(Om_HDHB_back(i), M, N);
%     X_HDHB_hat = blkdiag(pinvE, pinvE) * X(1 : end - 1, i);
%     Amplitude_HDHB_back(i) = abs(X_HDHB_hat(1));
%     for j = 1 : N
%         Amplitude_HDHB_back(i) = Amplitude_HDHB_back(i) + sqrt(X_HDHB_hat(2 * j) ^ 2 + X_HDHB_hat(2 * j + 1) ^ 2);
%     end
% end

%% Illustrate results
% figure;
subplot(1, 4, 4);
maker_idx = 1 : floor(length(Om_HB) / 40) : length(Om_HB);
Plotnum1 = plot(Om_HB, Amplitude_HB, 'ko', 'LineWidth', 1.5, 'Markersize', 3, 'MarkerFaceColor', 'k', 'MarkerIndices',maker_idx);
hold on;
% Plotnum2 = plot(Om_HDHB_for, Amplitude_HDHB_for, '-', 'LineWidth', 2, 'Color', [0.31176 0.59216 0.54510]);
% hold on;
% plot(Om_HDHB_back, Amplitude_HDHB_back, '-', 'LineWidth', 1, 'Color', [0.31176 0.59216 0.54510]);
% hold on;
Plotnum3 = plot(Om_RHB, Amplitude_RHB, '-', 'LineWidth', 1.5, 'Color', [0.69020 0.18824 0.37647]);
xlabel('Frequency, \omega', 'Fontsize', 16, 'FontName', 'Times New Roman');
ylabel('Amplitude', 'FontSize', 16, 'FontName', 'Times New Roman');
set(gca, 'FontSize', 16, 'FontName', 'Times New Roman');
% legend([Plotnum1, Plotnum2, Plotnum3], ' HB', ' HDHB', ' RHB', 'FontSize', 16, 'FontName', 'Times New Roman', 'Box', 'off');
legend([Plotnum1, Plotnum3], ' HB', ' M = 13 (RHB)', 'FontSize', 16, 'FontName', 'Times New Roman', 'Box', 'off');
axis([0 Om_e 0 3.5]);
hold on;