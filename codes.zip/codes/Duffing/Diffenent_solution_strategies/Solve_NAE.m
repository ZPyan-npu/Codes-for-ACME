function [X, Xdot_hat, Error] = Solve_NAE(N, M, Omega, zeta, kappa, gamma, P, phi, A_tilde, X, Max_iter, SolverMark)
    Error = zeros(Max_iter, 1);
    [~, R] = Solve_NAE_Jacobian(X, N, M, Omega, A_tilde, zeta, kappa, gamma, P, phi);
    Error(1) = sum(abs(R));
    
    num_Error = 1;
    while num_Error < Max_iter
        X_Former = X;
        [J, R] = Solve_NAE_Jacobian(X, N, M, Omega, A_tilde, zeta, kappa, gamma, P, phi);
        
        switch SolverMark
            case 1 % NRM
                X = X_Former - J \ R;
            case 2 % ODBA(R)
                Bk = J;
                Fk = R;
                Rk = Bk' * Fk;
                Pk = Rk - sum(Rk .^ 2) / (Rk' * (Bk' * Bk) * Rk) * (Bk' * Bk) * Rk;
                v1k = Bk * Rk;
                v2k = Bk * Pk;
                factor1 = v2k' * Fk * sum(v1k .^ 2) - v1k' * v2k * (v1k' * Fk);
                factor2 = v1k' * Fk * sum(v2k .^ 2) - v1k' * v2k * (v2k' * Fk);
                if factor2 == 0
                    wk = 1;
                else
                    wk = factor1 / factor2;
                end
                alpha = 1 / (1 + wk);
                beta = wk / (1 + wk);
                uk = alpha * Rk + beta * Pk;
                vk = alpha * v1k + beta * v2k;
                X = X_Former - (1 - 0.3) * Fk' * vk / (sum(vk .^ 2)) * uk;
            case 3 % GOIA
                Bk = J;
                Ak = J * J';
                vk1 = Ak * R;
                vk2 = Bk * R;
                ack = (vk1' * vk1 * (vk2' * vk2) - (vk1' * vk2) ^ 2) / sum(((vk1' * R) * vk2 - (vk2' * R) * vk1) .^ 2);
                alpha = (ack * R' * vk1 * R' * vk2 - vk1' * vk2) / (vk2' * vk2 - ack * (R' * vk2) ^ 2);
                if alpha == inf
                    alpha = 0;
                end
                uk = alpha * R + Bk' * R;
                vk = vk1 + alpha * vk2;
                X = X_Former - (1 - 0.3) * R' * vk / sum(vk .^ 2) * uk;
            case 4 % OIA/ODV(R)
                Fk = R;
                Bk = J;
                Rk = Bk' * Fk;
                Pk = Rk - sum(Rk .^ 2) / (Rk' * (Bk' * Bk) * Rk) * (Bk' * Bk) * Rk;
                v1k = Bk * Rk;
                v2k = Bk * Pk;
                factor1 = v2k' * Fk * sum(v1k .^ 2) - v1k' * v2k * (v1k' * Fk);
                factor2 = v1k' * Fk * sum(v2k .^ 2) - v1k' * v2k * (v2k' * Fk);
                if factor2 == 0
                    wk = 1;
                else
                    wk = factor1 / factor2;
                end
                alpha = 1 / (1 + wk);
                beta = wk / (1 + wk);
                uk = alpha * Rk + beta * Pk;
                vk = alpha * v1k + beta * v2k;
                X = X_Former - (1 - 0.2) * Fk' * vk / (sum(vk .^ 2)) * uk;
        end
        
        num_Error = num_Error + 1;
        Error(num_Error) = sum(abs(R));
        Xdot_hat = Omega * A_tilde * X;
    end
end

function [J, R2] = Solve_NAE_Jacobian(X_hat, N, M, Omega, A_tilde, zeta, kappa, gamma, P, phi)
    h = 1e-8;
    J = zeros(2 * (2 * N + 1), 2 * (2 * N + 1));
    R2 = Residual_Duffing([X_hat; Omega], zeta, kappa, gamma, P, N, M, A_tilde, phi);
    for i = 1 : 2 * (2 * N + 1)
        Xp_hat = X_hat;
        Xp_hat(i) = Xp_hat(i) + h;
        R1 = Residual_Duffing([Xp_hat; Omega], zeta, kappa, gamma, P, N, M, A_tilde, phi);
        J(:, i) = (R1 - R2) / h;
    end
end

function R = Residual_Duffing(X, zeta, kappa, gamma, P, N, M, A_tilde, phi)
    Om = X(end);                           % excitation frequency
    T = 2 * pi / Om;                       % period
    t_i = (0 : M - 1) / M * T; t_i = t_i'; % collocations
    H = sin(Om .* t_i);
    
    [E, pinvE] = Changeable_values(Om, M, N);
    E_tilde = blkdiag(E, E);
    pinvE_tilde = blkdiag(pinvE, pinvE);
    X_tilde = E_tilde * X(1 : end - 1);
    
    Linear_coef1 = [0 * eye(M), 1 * eye(M); -kappa * eye(M), -zeta * eye(M)];
    Nonlinear_coef1 = [0 * eye(M), 0 * eye(M); -gamma * eye(M), 0 * eye(M)];
    External_coef = [0 * ones(M, 1); P * H];
    
    R = Om * A_tilde * X(1 : end - 1) - pinvE_tilde * Linear_coef1 * X_tilde - pinvE_tilde * Nonlinear_coef1 * X_tilde .^ phi - pinvE_tilde * External_coef;
end