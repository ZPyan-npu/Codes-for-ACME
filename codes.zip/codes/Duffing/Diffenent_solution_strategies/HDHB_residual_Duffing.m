%===================================================================================================
% DESCRIPTION: 
% Matlab function setting up the time-domain residual vector 'R' and its derivatives for given 
% frequency 'Om' and vector of harmonics of the generalized coordiantes 'Q'. The corresponding model
% is a single DOF oscillator with cubic Duffing oscillator governed by the time-domain equation of 
% motion
% 
%       mu * \ddot q + zeta * \dot q + kappa * q + gamma * q^phi = P * sin(Om*t).
% 
%===================================================================================================
function R = HDHB_residual_Duffing(X, zeta, kappa, gamma, P, N, M, A_tilde, phi)
    Om = X(end);                           % excitation frequency
    T = 2 * pi / Om;                       % period
    t_i = (0 : M - 1) / M * T; t_i = t_i'; % collocations
    H = sin(Om .* t_i);
    
    [E, pinvE] = Changeable_values(Om, M, N);
    E_tilde = blkdiag(E, E);
    pinvE_tilde = blkdiag(pinvE, pinvE);
    
    Linear_coef = [0 * eye(M), 1 * eye(M); -kappa * eye(M), -zeta * eye(M)];
    Nonlinear_coef = [0 * eye(M), 0 * eye(M); -gamma * eye(M), 0 * eye(M)];
    External_coef = [0 * ones(M, 1); P * H];
    
    X_tilde = X(1 : end - 1);
    R = Om * E_tilde * A_tilde * pinvE_tilde * X_tilde - Linear_coef * X_tilde - Nonlinear_coef * X_tilde .^ phi - External_coef;
end

