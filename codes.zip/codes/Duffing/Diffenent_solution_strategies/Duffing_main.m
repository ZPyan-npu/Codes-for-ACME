%=======================================================================================================
% DESCRIPTION: 
% Investigation of the dynamics the Duffing oscillator, under harmonic external forcing and light linear 
% viscous damping. The dynamics are governed by the second-order ordinary diferential equation,
%   \ddot q + zeta \dot q + kappa q + \gamma q^3 = P sin( Om * t ).
%=======================================================================================================
% clearvars;
% close all;
% clc;

%% Parameters of the Duffing oscillator and analysis
[kappa, P, zeta, phi, gamma] = System_coefficients(); % Duffing oscillator parameters
N = 3;                    % harmonic order

for num_Om = 1 : 6
    Om_s = 0.1 * (num_Om + 1);               % start frequency
    [A] = Constant_values(N); % matrix A
    A_tilde = blkdiag(A, A);
    Max_iter = 500;           % Maximum of the iteration
    SolverMark = 3;           % NAE solver mark

    %% Compute
    M = (phi + 1) * N + 1; % Number of collocations
    X_hat_Initial = 0 * ones(2 * (2 * N + 1), 1); % Initial Fourier coefficients
    [~, ~, Error_NR] = Solve_NAE(N, M, Om_s, zeta, kappa, gamma, P, phi, A_tilde, X_hat_Initial, Max_iter, 1); % Solution point

    [~, ~, Error_GOIA] = Solve_NAE(N, M, Om_s, zeta, kappa, gamma, P, phi, A_tilde, X_hat_Initial, Max_iter, 3); % Solution point

    %% Illustrate results
    % figure;
    subplot(2, 3, num_Om);
    maker_idx = 1 : Max_iter / 50 : Max_iter;
    Plotnum1 = plot(1 : Max_iter, Error_NR, '-', 'LineWidth', 1, 'Color', [0.69020 0.18824 0.37647], 'MarkerFaceColor', '[1 0.41176 0.70588]', 'MarkerIndices', maker_idx);
    hold on;
    Plotnum2 = plot(1 : Max_iter, Error_GOIA, '-', 'LineWidth', 1, 'Color', [0.21176 0.39216 0.54510], 'MarkerFaceColor', '[0 0.74902 1]', 'MarkerIndices', maker_idx);
    xlabel('Iteration', 'Fontsize', 16, 'FontName', 'Times New Roman');
    ylabel('Residual', 'FontSize', 16, 'FontName', 'Times New Roman');
    set(gca, 'FontSize', 16, 'FontName', 'Times New Roman');
    set(gca,'yscale','log');
    xlim([0 Max_iter]);
    legend([Plotnum1, Plotnum2], ' NRM', ' GOIA', 'FontSize', 16, 'FontName', 'Times New Roman', 'Box', 'off');
end
% axis([0 500 1e-16 1]);