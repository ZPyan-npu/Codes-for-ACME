function [A] = Constant_values(N)
    A = zeros(2 * N + 1);
    for i = 1 : 2 * N + 1
        for j = 1 : 2 * N + 1
            if floor(i / 2) == floor(j / 2)
                if i > j
                    A(i, j) = -floor(i / 2);
                elseif i < j
                    A(i, j) = floor(i / 2);
                end
            end
        end
    end
end