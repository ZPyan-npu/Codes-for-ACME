function [E, pinvE] = Changeable_values(Omega, M, N)
    E = zeros(M, 2 * N + 1);
    pinvE = zeros(2 * N + 1, M);
    for i = 1 : M
		ti = 2 * pi / Omega * (i - 1.0) / M;
        for j = 1 : 2 * N + 1
            if (j == 1)
				E(i,j) = 1;
				pinvE(j,i) = 1.0 / 2.0 * 2.0 / M;
            else
                if (mod(j,2) == 0)
					E(i,j) = cos((floor(j / 2)) * Omega * ti);
					pinvE(j,i) = 2.0 / M * cos((floor(j / 2)) * Omega * ti);
                else
					E(i,j) = sin((floor(j / 2)) * Omega * ti);
					pinvE(j,i) = 2.0 / M * sin((floor(j / 2)) * Omega * ti);
                end
            end
        end
    end
end