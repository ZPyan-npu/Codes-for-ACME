function [kappa, P, zeta, Phi, gamma] = System_coefficients()
    gamma = 1; % nonlinear coefficient
    kappa = 1; % stiffness
    P = 1.25;  % the forcing amplitude
    zeta = 0.2;% damping
    Phi = 3;   % degree of nonlinear term
end