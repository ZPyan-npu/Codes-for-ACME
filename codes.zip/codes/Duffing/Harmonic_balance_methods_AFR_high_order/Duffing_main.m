%=======================================================================================================
% DESCRIPTION: 
% Investigation of the dynamics the Duffing oscillator, under harmonic external forcing and light linear 
% viscous damping. The dynamics are governed by the second-order ordinary diferential equation,
%   \ddot q + zeta \dot q + kappa q + \gamma q^3 = P sin( Om * t ).
%=======================================================================================================
clearvars;
close all;
clc;

%% Parameters of the Duffing oscillator and analysis
[kappa, P, zeta, phi, gamma] = System_coefficients(); % Duffing oscillator parameters
Om_s = 0.01;              % start frequency
Om_e = 1.00;              % end frequency

[A] = Constant_values(1); % matrix A
A_tilde = blkdiag(A, A);
[X_hat_first_HB1, ~] = Initialguess(1, Om_s, zeta, kappa, P, A_tilde, 0 * ones(2 * (2 * 1 + 1), 1));
% X_hat_first_HB1 = [0;-1.43994749088881;1.53390812622104;0;0;0.0648652029811643;0.0491624431188463;0;3.07731732711343;2.88881406474487;0;0;0.295888199327815;-0.390396547136785];

for num = 1 : 6
%% Compute frequency response using the RHB method (benchmark)
    % Harmonic order
    N = num + 3;

    [A] = Constant_values(N); % matrix A
    A_tilde = blkdiag(A, A);

    % Number of collocations
    M = (phi + 1) * N + 1;

    % Initial guess
    X_hat_first = 0 * ones(2 * (2 * N + 1), 1);%Initial Fourier coefficients
    X_hat_first(1 : length(X_hat_first_HB1)) = X_hat_first_HB1;

    % Solve and continuation
    ds = 0.01;                       % Path continuation step size
    Sopt = struct('jac', 'none');    % No analytical Jacobian provided here
    X = solve_and_continue(X_hat_first, @(X) RHB_residual_Duffing(X, zeta, kappa, gamma, P, N, M, A_tilde, phi), Om_s, Om_e, ds, Sopt);

    % Determine excitation frequency and amplitude (magnitude of fundamental harmonic)
    Om_RHB(num).om = X(end, :);
    Amplitude_RHB(num).Amp = zeros(1, length(X(end, :)));
    for i = 1 : length(X(end, :))
        X_RHB_hat = X(1 : end - 1, i);
        Amplitude_RHB(num).Amp(i) = abs(X_RHB_hat(1));
        for j = 1 : N
            Amplitude_RHB(num).Amp(i) = Amplitude_RHB(num).Amp(i) + sqrt(X_RHB_hat(2 * j) ^ 2 + X_RHB_hat(2 * j + 1) ^ 2);
        end
    end

%% Compute frequency response using the HDHB method
    N = num + 3;
    % Number of collocations
    M = 2 * N + 1;
    
    [A] = Constant_values(N); % matrix A
    A_tilde = blkdiag(A, A);

    % Initial guess
    [E, ~] = Changeable_values(Om_s, M, N);
    E_tilde = blkdiag(E, E);
    X_tilde_first = E_tilde * X_hat_first;

    % Solve and continuation
    X = solve_and_continue(X_tilde_first, @(X) HDHB_residual_Duffing(X, zeta, kappa, gamma, P, N, M, A_tilde, phi), Om_s, Om_e, ds, Sopt);

    % Determine excitation frequency and amplitude (magnitude of fundamental harmonic)
    Om_HDHB_for(num).om = X(end, :);
    Amplitude_HDHB_for(num).Amp = zeros(1, length(X(end, :)));
    for i = 1 : length(X(end, :))
        [~, pinvE] = Changeable_values(Om_HDHB_for(num).om(i), M, N);
        X_HDHB_hat = blkdiag(pinvE, pinvE) * X(1 : end - 1, i);
        Amplitude_HDHB_for(num).Amp(i) = abs(X_HDHB_hat(1));
        for j = 1 : N
            Amplitude_HDHB_for(num).Amp(i) = Amplitude_HDHB_for(num).Amp(i) + sqrt(X_HDHB_hat(2 * j) ^ 2 + X_HDHB_hat(2 * j + 1) ^ 2);
        end
    end
end

%% Illustrate results
% figure;
% color1 = lines(24);
for num = 1 : 6
    subplot(2, 3, num);
%     maker_idx = 1 : floor(length(Om_RHB(num).om) / 100) : length(Om_RHB(num).om);
    maker_idx = 1 : length(Om_RHB(num).om);
    Plotnum1 = plot(Om_RHB(num).om, Amplitude_RHB(num).Amp, 'ko', 'LineWidth', 2, 'Markersize', 3, 'MarkerFaceColor', 'k', 'MarkerIndices',maker_idx);
    hold on;
    Plotnum2 = plot(Om_HDHB_for(num).om, Amplitude_HDHB_for(num).Amp, '-', 'LineWidth', 2, 'Color', [0.31176 0.59216 0.54510]);
    hold on;
    xlabel('Frequency, \omega', 'Fontsize', 16, 'FontName', 'Times New Roman');
    ylabel('Amplitude', 'FontSize', 16, 'FontName', 'Times New Roman');
    set(gca, 'FontSize', 16, 'FontName', 'Times New Roman');
    legend([Plotnum1, Plotnum2], ' RHB', ' HDHB', 'FontSize', 16, 'FontName', 'Times New Roman', 'Box', 'off');
    axis([0 Om_e 0.5 2]);
end