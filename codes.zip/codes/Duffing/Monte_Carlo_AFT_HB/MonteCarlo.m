clear;
clc;

N = 2;%г������%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
M = (3 + 1) * N + 1;

Beta = 1;
F = 1.25;
Kesi = 0.1;

mon_num = 1e4;

Omega = 2;

subplot(1,2,1);

x1=10*rand(mon_num,1)-5*ones(mon_num,1);
x2=zeros(mon_num,1);
for i=1:mon_num
    x2(i)=2*sqrt(25-x1(1))*rand(1)-sqrt(25-x1(1));
end

invE=[];
for i=1:M
    t_i=2*(i-1)*pi/((M)*Omega)+0*pi/Omega;
    Theta_i=Omega*t_i;
    invE1=1;
    for num=1:N
        invE1=[invE1,cos(num*Theta_i),sin(num*Theta_i)];
    end
    invE=[invE;invE1];
end

X=zeros(mon_num,2*N+1);

X(:,2)=x1;
X(:,3)=x2;

Qxb=zeros(mon_num,M);
for i=1:mon_num
    Qxb(i,:)=invE*X(i,:)';
end
% X1=10*rand(mon_num,M)-5*ones(mon_num,M);

solutionnum=0;
cantnum=0;
NaNnum=0;
for num=1:mon_num
    Qxb1=Qxb(num,:)';
    [X,~,flag]=Newton_Raphson(M,N,Omega,Kesi,Beta,F,Qxb1);
    if flag==1
        cantnum=cantnum+1;
        continue;
    elseif flag==2
        NaNnum=NaNnum+1;
        continue;
    end
            
    flag=0;
    if solutionnum==0
        solutionnum=solutionnum+1;
        solution(solutionnum,1:2*N+1)=X;
        solution(solutionnum,2*N+2)=1;
    else
        for j=1:solutionnum
            if norm(X'-solution(j,1:2*N+1))<1e-3
                flag=1;
                solution(j,2*N+2)=solution(j,2*N+2)+1;
                break;
            else
                flag=2;
%                 solution(j,2*N+2)=1;
                continue;
            end
        end
        if flag==2
            solutionnum=solutionnum+1;
            solution(solutionnum,1:2*N+1)=X;
            solution(solutionnum,2*N+2)=1;
        end
    end
    num
end

for j=1:solutionnum
    Amplitude1=sqrt(solution(j,1)^2);
    for i=1:N
        Amplitude1=Amplitude1+sqrt(solution(j,2*i)^2+solution(j,2*i+1)^2);
    end
    Amplitude(j)=Amplitude1;
    probability(j)=(solution(j,2*N+2)/sum(solution(:,2*N+2)));
end

bar(Amplitude,probability,0.02,'k');
set(gca,'yscale','log');
xlabel('Peak Amplitude, A','fontsize',20,'fontname','Times New Roman');
ylabel('Probability','fontsize',20,'fontname','Times New Roman');

% annotation('arrow',[3 0.02/3],[0.434475910434193 0.02/3]);
% annotation('arrow',[3 0.02*2/3],[1.85209045067151 0.02*2/3]);
% annotation('arrow',[3 0.1],[2.29241154529314 0.1]);
% text(3,0.02/3,'\fontsize{18}lower branch, ');
% text(3,0.02*2/3,'\fontsize{18}unstable branch, ');
% text(3,0.1,'\fontsize{18}upper branch, ');


hold on;



M=2*N+1;

Beta=1;
F=1.25;
Kesi=0.1;


mon_num=1e4;

Omega=2;

subplot(1,2,2);

x1=10*rand(mon_num,1)-5*ones(mon_num,1);
x2=zeros(mon_num,1);
for i=1:mon_num
    x2(i)=2*sqrt(25-x1(1))*rand(1)-sqrt(25-x1(1));
end

invE=[];
for i=1:M
    t_i=2*(i-1)*pi/((M)*Omega)+0*pi/Omega;
    Theta_i=Omega*t_i;
    invE1=1;
    for num=1:N
        invE1=[invE1,cos(num*Theta_i),sin(num*Theta_i)];
    end
    invE=[invE;invE1];
end

X=zeros(mon_num,2*N+1);

X(:,2)=x1;
X(:,3)=x2;

Qxb=zeros(mon_num,M);
for i=1:mon_num
    Qxb(i,:)=invE*X(i,:)';
end
% X1=10*rand(mon_num,M)-5*ones(mon_num,M);

solutionnum=0;
cantnum=0;
NaNnum=0;
for num=1:mon_num
    Qxb1=Qxb(num,:)';
    [X,~,flag]=Newton_Raphson(M,N,Omega,Kesi,Beta,F,Qxb1);
    if flag==1
        cantnum=cantnum+1;
        continue;
    elseif flag==2
        NaNnum=NaNnum+1;
        continue;
    end
            
    flag=0;
    if solutionnum==0
        solutionnum=solutionnum+1;
        solution(solutionnum,1:2*N+1)=X;
        solution(solutionnum,2*N+2)=1;
    else
        for j=1:solutionnum
            if norm(X'-solution(j,1:2*N+1))<1e-3
                flag=1;
                solution(j,2*N+2)=solution(j,2*N+2)+1;
                break;
            else
                flag=2;
%                 solution(j,2*N+2)=1;
                continue;
            end
        end
        if flag==2
            solutionnum=solutionnum+1;
            solution(solutionnum,1:2*N+1)=X;
            solution(solutionnum,2*N+2)=1;
        end
    end
    num
end

for j=1:solutionnum
    Amplitude1=sqrt(solution(j,1)^2);
    for i=1:N
        Amplitude1=Amplitude1+sqrt(solution(j,2*i)^2+solution(j,2*i+1)^2);
    end
    Amplitude(j)=Amplitude1;
    probability(j)=(solution(j,2*N+2)/sum(solution(:,2*N+2)));
end
bar(Amplitude,probability,0.02,'k');
set(gca,'yscale','log');
xlabel('Peak Amplitude, A','fontsize',20,'fontname','Times New Roman');
ylabel('Probability','fontsize',20,'fontname','Times New Roman');

% annotation('arrow',[3 0.02/3],[0.434475910434193 0.02/3]);
% annotation('arrow',[3 0.02*2/3],[1.85209045067151 0.02*2/3]);
% annotation('arrow',[3 0.1],[2.29241154529314 0.1]);
% text(3,0.02/3,'\fontsize{18}lower branch, ');
% text(3,0.02*2/3,'\fontsize{18}unstable branch, ');
% text(3,0.1,'\fontsize{18}upper branch, ');
