clear
clc

Beta = 1;%nonlinear coefficient
F = 1.25;%the forcing amplitude
Kesi = 0.1;%damping
Omega = 0.2;

subplot(1, 2, 1);
phi = 3;
%% Benchmark
N_B = 200;%order
M_B = (3 + 1) * N_B + 1;%RHB collocations
X_hat_Initial = 0 * ones(1, M_B)';%Initial Fourier coefficients
[X_hat_Ben, invE] = Newton_Raphson(M_B, N_B, Omega, Kesi, Beta, F, X_hat_Initial, phi);
X_tilde_Ben = invE * X_hat_Ben;
%% RHB
num = 1;
for N = 1 : 1 : 100
    M = (3 + 1) * N + 1;%RHB collocations
    X_hat_Initial = 0 * ones(1, M)';%Initial Fourier cofficients
    [X_hat, ~] = Newton_Raphson(M, N, Omega, Kesi, Beta, F, X_hat_Initial, phi);
    t_i = 2 * ((0 : M_B - 1)) * pi ./ (M_B * Omega);
    X_tilde = X_hat(1);
    for i = 1 : N
        X_tilde = X_tilde + X_hat(2 * i) .* cos(i * Omega .* t_i) + X_hat(2 * i + 1) .* sin(i * Omega .* t_i);
    end
    X_tilde = X_tilde';
    Error(num) = norm(X_tilde - X_tilde_Ben) / M_B;
    num = num + 1;
end

maker_idx = 1 : 2 : 100;
plot(1 : 1 : 100, Error, '->', 'Color', [0 0 0], 'MarkerFaceColor', [0.74510 0.74510 0.74510], 'MarkerIndices',maker_idx);
xlabel('Truncated order', 'fontsize', 16);
ylabel('Error', 'fontsize', 16);
set(gca, 'FontSize', 16);
set(gca,'yscale','log');


subplot(1, 2, 2);
phi = 5;
%% Benchmark
N_B = 200;%order
M_B = (5 + 1) * N_B + 1;%RHB collocations
X_hat_Initial = 0 * ones(1, M_B)';%Initial Fourier coefficients
[X_hat_Ben, invE] = Newton_Raphson(M_B, N_B, Omega, Kesi, Beta, F, X_hat_Initial, phi);
X_tilde_Ben = invE * X_hat_Ben;
%% RHB
num = 1;
for N = 1 : 1 : 100
    M = (3 + 1) * N + 1;%RHB collocations
    X_hat_Initial = 0 * ones(1, M)';%Initial Fourier cofficients
    [X_hat, ~] = Newton_Raphson(M, N, Omega, Kesi, Beta, F, X_hat_Initial, phi);
    t_i = 2 * ((0 : M_B - 1)) * pi ./ (M_B * Omega);
    X_tilde = X_hat(1);
    for i = 1 : N
        X_tilde = X_tilde + X_hat(2 * i) .* cos(i * Omega .* t_i) + X_hat(2 * i + 1) .* sin(i * Omega .* t_i);
    end
    X_tilde = X_tilde';
    Error(num) = norm(X_tilde - X_tilde_Ben) / M_B;
    num = num + 1;
end

maker_idx = 1 : 2 : 100;
plot(1 : 1 : 100, Error, '->', 'Color', [0 0 0], 'MarkerFaceColor', [0.74510 0.74510 0.74510], 'MarkerIndices',maker_idx);
xlabel('Truncated order', 'fontsize', 16);
ylabel('Error', 'fontsize', 16);
set(gca, 'FontSize', 16);
set(gca,'yscale','log');