function [X, invE] = Newton_Raphson(M, N, Omega, Kesi, Beta, F, Qxb, phi)
    flag = 0;
    error_lim = 1e-12;
    error = 1;
    A = zeros(2 * N + 1);
    for i = 1 : 2 * N + 1
        for j = 1 : 2 * N + 1
            if floor(i / 2) == floor(j / 2)
                if i > j
                    A(i, j) = -floor(i / 2);
                elseif i < j
                    A(i, j) = floor(i / 2);
                end
            end
        end
    end
    I = eye(2 * N + 1);
    invE = [];
    H = zeros(2 * N + 1, 1);
    H(3,1) = 1;
    
    Hb = [];
    for i = 1 : M
        t_i = 2 * (i - 1) * pi / (M * Omega);
        Theta_i = Omega * t_i;
        invE1 = 1;
        for num = 1 : N
            invE1 = [invE1, cos(num * Theta_i), sin(num * Theta_i)];
        end
        invE = [invE; invE1];
        Hb = [Hb; sin(Theta_i)];
    end
    
    X = pinv(invE) * Qxb;
    
    dd = 1;
    while error > error_lim
        if phi == 3
            Rxb = Qxb .* Qxb .* Qxb;
        else
            if phi == 5
                Rxb = Qxb .* Qxb .* Qxb .* Qxb .* Qxb;
            end
        end
        R = (Omega ^ 2 * A * A + 2 * Kesi * Omega * A + I) * X + pinv(invE) * Rxb - F * H;
        J = jacobi(M, N, Omega, Kesi, Beta, Qxb, A, invE, phi);
        
        error = norm(R);
        
        X = X - J \ R;
        Qxb = invE * X;
        
        dd = dd + 1;
    end
end