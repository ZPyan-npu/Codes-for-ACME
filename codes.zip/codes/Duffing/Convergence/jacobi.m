function J = jacobi(M, N, Omega, Kesi, Beta, Qxb, A, invE, phi)
    I = eye(2 * N + 1);
    Rxb_QxT = [];
    for i = 1 : M
        x_t_i = Qxb(i);
        if phi == 3
            Rxb_QxT1 = (3 * x_t_i ^ 2) * invE(i, :);
        else
            if phi == 5
                Rxb_QxT1 = (5 * x_t_i ^ 4) * invE(i, :);
            end
        end
        Rxb_QxT = [Rxb_QxT; Rxb_QxT1];
    end
    J = (Omega ^ 2 * A * A + 2 * Kesi * Omega * A + I) + Beta * pinv(invE) * Rxb_QxT;
end