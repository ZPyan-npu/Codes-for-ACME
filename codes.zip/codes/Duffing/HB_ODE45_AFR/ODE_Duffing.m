function fty = ODE_Duffing(t, y, kappa, P, zeta, phi, gamma, Omega)
    fty=[y(2);
         -zeta * y(2) - kappa * y(1) - gamma * y(1) ^ phi + P * sin(Omega * t)];
end