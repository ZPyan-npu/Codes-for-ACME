%=======================================================================================================
% DESCRIPTION: 
% Investigation of the dynamics the Duffing oscillator, under harmonic external forcing and light linear 
% viscous damping. The dynamics are governed by the second-order ordinary diferential equation,
%   \ddot q + zeta \dot q + kappa q + \gamma q^3 = P sin( Om * t ).
%=======================================================================================================
% clearvars;
% close all;
% clc;

%% Parameters of the Duffing oscillator and analysis
[kappa, P, zeta, phi, gamma] = System_coefficients(); % Duffing oscillator parameters
Om_s = 0.01;              % start frequency
Om_e = 3.00;              % end frequency
Dt = 0.01;

%% ODE45 results
[Omega_upper_ODE_for, Amplitude_upper_ODE_for, Omega_lower_ODE_for, Amplitude_lower_ODE_for] = Main_ODE(Om_s : Dt : Om_e, kappa, P, zeta, phi, gamma);

%% Compute frequency response using the HB method
N = 7; % harmonic order
[A] = Constant_values(N); % matrix A
A_tilde = blkdiag(A, A);

% Initial guess
X_hat_Initial = 0 * ones(2 * (2 * N + 1), 1);%Initial Fourier coefficients
[X_hat_first, ~] = Initialguess(N, Om_s, zeta, kappa, gamma, P, A_tilde, X_hat_Initial);%the first solution point
% Solve and continuation
ds = 0.01;                       % Path continuation step size
Sopt = struct('jac', 'none');    % No analytical Jacobian provided here
X = solve_and_continue(X_hat_first, @(X) HB_residual_Duffing(X, zeta, kappa, gamma, P, N, A_tilde), Om_s, Om_e, ds, Sopt);

% Determine excitation frequency and amplitude (magnitude of fundamental harmonic)
Om_HB = X(end, :)';
num = length(Om_HB);
Amplitude_HB = zeros(num, 1);
for j = 1 : num
    T = 2 * pi ./ Om_HB(j) + Dt;
    X_tilde = X(1, j);
    for i = 1 : N
        X_tilde = X_tilde + X(2 * i, j) * cos(i * Om_HB(j) * (0 : Dt : T)') + X(2 * i + 1, j) * sin(i * Om_HB(j) * (0 : Dt : T)');
    end
    Amplitude_HB(j) = (max(X_tilde) - min(X_tilde)) ./ 2;
end