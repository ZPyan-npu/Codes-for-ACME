clear;
clc;

subplot(1, 2, 1);
PlotError();

%% ODE45 AFR results
load('Omega_upper_ODE_for.mat');
load('Amplitude_upper_ODE_for.mat');
load('Omega_lower_ODE_for.mat');
load('Amplitude_lower_ODE_for.mat');

%% HB7 AFR results
load('Om_HB7.mat');
load('Amplitude_HB7.mat');

%% AFR plot
subplot(1, 2, 2);
maker_idx1 = 1 : floor(length(Omega_upper_ODE_for) / 40) : length(Omega_upper_ODE_for);
maker_idx2 = 1 : floor(length(Omega_lower_ODE_for) / 20) : length(Omega_lower_ODE_for);
Plotnum1 = plot(Om_HB, Amplitude_HB, 'k', 'LineWidth', 1.5, 'Markersize', 3, 'MarkerFaceColor', 'k'); hold on;
Plotnum2 = plot(Omega_upper_ODE_for, Amplitude_upper_ODE_for, 'o', 'LineWidth', 1.5, 'Color', [0.31176 0.59216 0.54510], 'MarkerIndices', maker_idx1); hold on;
plot(Omega_lower_ODE_for, Amplitude_lower_ODE_for, 'o', 'LineWidth', 1.5, 'Color', [0.31176 0.59216 0.54510], 'MarkerIndices', maker_idx2);
xlabel('Frequency, \omega', 'Fontsize', 16, 'FontName', 'Times New Roman'); ylabel('Amplitude', 'FontSize', 16, 'FontName', 'Times New Roman');
legend([Plotnum2, Plotnum1], ' ODE45', ' HB7', 'FontSize', 16, 'FontName', 'Times New Roman', 'Box', 'off');
set(gca, 'FontSize', 16, 'FontName', 'Times New Roman'); axis([0 3 0 3.5]);