function [Omega_upper_ODE, Amplitude_upper_ODE, Omega_lower_ODE, Amplitude_lower_ODE] = Main_ODE(Range, kappa, P, zeta, phi, gamma)
    [~, num] = size(Range);
    if Range(1) > Range(end)
        direction = -1;
    else
        direction = 1;
    end
    Amplitude = zeros(num, 1);
    Omega_ODE = Range;
    option = odeset('reltol', 1e-6, 'abstol', 1e-6);
    tspan = 0 : 1e-2 : 400;
    
    y(1) = 0; y(2) = 0;
    initial = [y(1); y(2)];
    for i = 1 : num
        [~, y] = ode45(@ODE_Duffing, tspan, initial, option, kappa, P, zeta, phi, gamma, Omega_ODE(i));
        Amplitude(i) = (max(y(25000 : end, 1)) - min(y(25000 : end, 1))) / 2;
        initial = y(end, :);
    end
    [~, p] = max(Amplitude);
    if direction == 1
        Amplitude_upper_ODE = Amplitude(1 : p);
        Amplitude_lower_ODE = Amplitude(p + 1 : end);
        Omega_upper_ODE = Range(1 : p);
        Omega_lower_ODE = Range(p + 1 : end);
    else
        Amplitude_upper_ODE = Amplitude(p : end);
        Amplitude_lower_ODE = Amplitude(1 : p - 1);
        Omega_upper_ODE = Range(p : end);
        Omega_lower_ODE = Range(1 : p - 1);
    end
end