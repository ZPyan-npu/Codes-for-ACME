function [X_hat, Xdot_hat] = Initialguess(N, Omega, zeta, kappa, gamma, P, A_tilde, X_hat)
    Error_lim = 1e-8;
    Error = 1;
    
    while Error > Error_lim
        X_hatFormer = X_hat;
        [J, R] = Initialguess_Jacobian(X_hat, N, Omega, A_tilde, zeta, kappa, gamma, P);
        X_hat = X_hatFormer - pinv(J) * R;
        Error = sum(abs(R));
        Xdot_hat = Omega * A_tilde * X_hat;
    end
end

function [J, R2] = Initialguess_Jacobian(X_hat, N, Omega, A_tilde, zeta, kappa, gamma, P)
    h = 1e-8;
    J = zeros(2 * (2 * N + 1), 2 * (2 * N + 1));
    R2 = HB_residual_Duffing([X_hat; Omega], zeta, kappa, gamma, P, N, A_tilde);
    for i = 1 : 2 * (2 * N + 1)
        Xp_hat = X_hat;
        Xp_hat(i) = Xp_hat(i) + h;
        R1 = HB_residual_Duffing([Xp_hat; Omega], zeta, kappa, gamma, P, N, A_tilde);
        J(:, i) = (R1 - R2) / h;
    end
end