clear;
clc;

% N = 10;
% Beta = 1;
% F = 1.25;
% Kesi = 0.1;
% mon_num = 1e4;
% 
% solution_num_HDHB = zeros(30, 1);
% solution_num_RHB = zeros(30, 1);
% k = 1;
% % for Omega = 0.1 : 0.1 : 3.0
% for Omega = 2.0
%     M = 2 * N + 1;
%     
%     x1 = 2.5 * (rand(mon_num, 1) - 0.5);
%     x2 = 2.5 * (rand(mon_num, 1) - 0.5);
%     
%     [E, ~] = Changeable_values(Omega, M, N);
% 
%     X = zeros(mon_num, 2 * N + 1);
%     X(:, 2) = x1;
%     X(:, 3) = x2;
%     Qxb = zeros(mon_num, M);
%     for i = 1 : mon_num
%         Qxb(i, :) = E * X(i, :)';
%     end
% 
%     solutionnum = 0;
%     cantnum = 0;
%     NaNnum = 0;
%     for num = 1 : mon_num
%         Qxb1 = Qxb(num, :)';
%         [X, ~, flag] = Newton_Raphson(M, N, Omega, Kesi, Beta, F, Qxb1);
%         if flag == 1
%             cantnum = cantnum + 1;
%             continue;
%         elseif flag == 2
%             NaNnum = NaNnum + 1;
%             continue;
%         end
%         
%         flag = 0;
%         if solutionnum == 0
%             solutionnum = solutionnum + 1;
%             solution(solutionnum, 1 : 2 * N + 1) = X;
%             solution(solutionnum, 2 * N + 2) = 1;
%         else
%             for j = 1 : solutionnum
%                 if norm(X' - solution(j, 1 : 2 * N + 1)) < 1e-3
%                     flag = 1;
%                     solution(j, 2 * N + 2) = solution(j, 2 * N + 2) + 1;
%                     break;
%                 else
%                     flag = 2;
%                     continue;
%                 end
%             end
%             if flag == 2
%                 solutionnum = solutionnum + 1;
%                 solution(solutionnum, 1 : 2 * N + 1) = X;
%                 solution(solutionnum, 2 * N + 2) = 1;
%             end
%         end
%         num
%     end
%     solution_num_HDHB(k) = solutionnum;
%     
%     M = 4 * N + 1;
%     
%     [E, pinvE] = Changeable_values(Omega, M, N);
% 
%     X = zeros(mon_num, 2 * N + 1);
%     X(:, 2) = x1;
%     X(:, 3) = x2;
%     Qxb = zeros(mon_num, M);
%     for i = 1 : mon_num
%         Qxb(i, :) = E * X(i, :)';
%     end
% 
%     solutionnum = 0;
%     cantnum = 0;
%     NaNnum = 0;
%     for num = 1 : mon_num
%         Qxb1 = Qxb(num, :)';
%         [X, ~, flag] = Newton_Raphson(M, N, Omega, Kesi, Beta, F, Qxb1);
%         if flag == 1
%             cantnum = cantnum + 1;
%             continue;
%         elseif flag == 2
%             NaNnum = NaNnum + 1;
%             continue;
%         end
%         
%         flag = 0;
%         if solutionnum == 0
%             solutionnum = solutionnum + 1;
%             solution(solutionnum, 1 : 2 * N + 1) = X;
%             solution(solutionnum, 2 * N + 2) = 1;
%         else
%             for j = 1 : solutionnum
%                 if norm(X' - solution(j, 1 : 2 * N + 1)) < 1e-3
%                     flag = 1;
%                     solution(j, 2 * N + 2) = solution(j, 2 * N + 2) + 1;
%                     break;
%                 else
%                     flag = 2;
%                     continue;
%                 end
%             end
%             if flag == 2
%                 solutionnum = solutionnum + 1;
%                 solution(solutionnum, 1 : 2 * N + 1) = X;
%                 solution(solutionnum, 2 * N + 2) = 1;
%             end
%         end
%     end
%     solution_num_RHB(k) = solutionnum;
%     k = k + 1;
% end

subplot(1, 2, 1);
solution_num_HDHB = [1; 1; 1; 1; 3; 5; 11; 15; 9; 13; 21; 31; 39; 43; 47; 57; 57; 59; 58; 59; 59; 58; 58; 57; 57; 54; 55; 53; 53; 48];
solution_num_RHB = [1; 1; 1; 1; 1; 1; 1; 1; 1; 1; 1; 1; 1; 1; 1; 1; 3; 3; 3; 3; 3; 3; 3; 3; 1; 1; 1; 1; 1; 1];
solution_num_HDHB = solution_num_HDHB - solution_num_RHB;
Bar1 = bar(0.1 : 0.1 : 3.0, solution_num_HDHB);
Bar1.FaceColor = [196 / 255, 208 / 255, 80 / 255];
% hold on;
% Bar2 = bar(0.1 : 0.1 : 3.0, solution_num_RHB);
% Bar2.FaceColor = [0 / 255, 120 / 255, 146 / 255];
grid on;
% PlotLegend = legend(Bar1, ' HDHB', ' RHB');
% set(PlotLegend, 'Box', 'off');
xlabel('Frequency, \omega');
ylabel('Number of solutions');

subplot(1, 2, 2);
solution_num_HDHB = [6; 20; 55; 118; 148; 199; 308; 425; 464; 494];
Bar1 = bar(1 : 10, solution_num_HDHB);
Bar1.FaceColor = [0 / 255, 176 / 255, 140 / 255];
grid on;
% set(PlotLegend, 'Box', 'off');
xlabel('Wavenumber');
ylabel('Number of non-physical solutions');