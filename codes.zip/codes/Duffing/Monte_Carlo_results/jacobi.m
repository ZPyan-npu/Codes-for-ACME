function J = jacobi(M, N, Omega, Kesi, Beta, Qxb, A, invE)
    I = eye(2 * N + 1);
    Rxb_QxT = [];
    for i = 1 : M
        x_t_i = Qxb(i);
        Rxb_QxT1 = (3 * x_t_i ^ 2) * invE(i, :);
        Rxb_QxT = [Rxb_QxT; Rxb_QxT1];
    end
    J = (Omega ^ 2 * A * A + 2 * Kesi * Omega * A + I) + Beta * pinv(invE) * Rxb_QxT;
end