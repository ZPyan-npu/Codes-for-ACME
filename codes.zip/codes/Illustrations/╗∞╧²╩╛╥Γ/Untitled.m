t = 0 : 0.01 : 2 * pi;

y11 = cos(1 * t);
y12 = cos(2 * t);
y21 = sin(1 * t);
y22 = -sin(4 * t);
y31 = sin(1 * t);
y32 = sin(6 * t);
y41 = cos(2 * t);
y42 = cos(8 * t);

color = lines(5);

subplot(2, 2, 1);
t_i = (0 : 2) * 2 * pi / 3;
plot(t, y11, 'LineWidth', 1.5, 'Color', color(1, :));
hold on;
plot(t, y12, 'LineWidth', 1.5, 'Color', color(2, :));
hold on;
plot(t_i, cos(1 * t_i), 'ko', 'MarkerSize', 6, 'MarkerFaceColor', [1 0.41176 0.70588]);
axis([0, 2 * pi, -1.5, 1.5]);

subplot(2, 2, 2);
t_i = (0 : 4) * 2 * pi / 5;
plot(t, y21, 'LineWidth', 1.5, 'Color', color(1, :));
hold on;
plot(t, y22, 'LineWidth', 1.5, 'Color', color(3, :));
hold on;
plot(t_i, sin(1 * t_i), 'ko', 'MarkerSize', 6, 'MarkerFaceColor', [1 0.41176 0.70588]);
axis([0, 2 * pi, -1.5, 1.5]);

subplot(2, 2, 3);
t_i = (0 : 4) * 2 * pi / 5;
plot(t, y31, 'LineWidth', 1.5, 'Color', color(1, :));
hold on;
plot(t, y32, 'LineWidth', 1.5, 'Color', color(4, :));
hold on;
plot(t_i, sin(1 * t_i), 'ko', 'MarkerSize', 6, 'MarkerFaceColor', [1 0.41176 0.70588]);
axis([0, 2 * pi, -1.5, 1.5]);

subplot(2, 2, 4);
t_i = (0 : 9) * 2 * pi / 10;
plot(t, y41, 'LineWidth', 1.5, 'Color', color(1, :));
hold on;
plot(t, y42, 'LineWidth', 1.5, 'Color', color(5, :));
hold on;
plot(t_i, cos(2 * t_i), 'ko', 'MarkerSize', 6, 'MarkerFaceColor', [1 0.41176 0.70588]);
axis([0, 2 * pi, -1.5, 1.5]);