alpha = 36;
m = 20;
n_s = 0 : 0.01 : pi;
G = exp(-alpha .* (n_s / pi) .^ m);

Plotnum1 = plot(n_s, G, 'LineWidth', 1.5, 'linestyle', '-', 'LineWidth', 1.5, 'Color', 'k');
set(gca, 'xTick', 0 : pi / 4 : pi);
set(gca, 'XTickLabel', {'0', '\pi/4','\pi/2', '3\pi/4', '\pi'});
hold on;
Plotnum2 = line([0 pi / 2], [1 1], 'linestyle', '--', 'LineWidth', 1.5);
hold on;
line([pi / 2 pi], [0 0], 'linestyle', '--', 'LineWidth', 1.5);
hold on;
line([pi / 2 pi / 2], [0 1], 'linestyle', '--', 'LineWidth', 1.5);

axis([0 pi -0.2 1.2])
xlabel('Normalized wavenumber, \omega_s');
ylabel('Transfer function Profile, G(\omega_s)');
set(gca, 'fontsize', 12);
set(gca, 'FontName', 'Times New Roman');
legend([Plotnum2, Plotnum1], ' One-half rule', ' Fourier smoothing', 'Box', 'off', 'fontsize', 12, 'FontName', 'Times New Roman');